<!-- CSS de Bootstrap -->
<link rel="stylesheet" href="../plugins/Bootstrap/css/bootstrap.min.css">
<!-- CSS de DataTables con Bootstrap -->
<link rel="stylesheet" href="../plugins/DataTables/css/dataTables.bootstrap5.min.css">

<!-- JS de jQuery (necesario para DataTables) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- JS de Bootstrap -->
<script src="../plugins/Bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- JS de DataTables -->
<script src="../plugins/DataTables/js/datatables.min.js"></script>
<!-- Integración de DataTables con Bootstrap -->
<script src="../plugins/DataTables/js/dataTables.bootstrap5.min.js"></script>
<!-- Tu archivo JS personalizado -->
<script src="mi_script.js"></script>